#!/bin/bash

# Script para iniciar a aplicação de controle de despesas

echo "Iniciando aplicação de Controle de Despesas..."

# Ativar ambiente virtual
source venv/bin/activate

# Verificar se o banco de dados existe, caso contrário criar
if [ ! -f despesas.db ]; then
    echo "Criando banco de dados..."
    python -c "from app import app, db; app.app_context().push(); db.create_all()"
fi

# Iniciar aplicação
echo "Servidor iniciando em http://localhost:5000"
python app.py

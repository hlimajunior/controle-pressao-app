from flask import Flask, render_template, request, redirect, url_for, flash, jsonify
from models import db, Despesa
from config import Config
from datetime import datetime
import gspread
from oauth2client.service_account import ServiceAccountCredentials
import os

app = Flask(__name__)
app.config.from_object(Config)

# Inicializar banco de dados
db.init_app(app)

# Criar tabelas
with app.app_context():
    db.create_all()


@app.route('/')
def index():
    """Página principal com listagem de despesas"""
    despesas = Despesa.query.order_by(Despesa.data.desc()).all()
    
    # Calcular total de despesas
    total = sum(despesa.valor for despesa in despesas)
    
    return render_template('index.html', 
                         despesas=despesas, 
                         total=total,
                         categorias=Config.CATEGORIAS)


@app.route('/adicionar', methods=['GET', 'POST'])
def adicionar():
    """Adicionar nova despesa"""
    if request.method == 'POST':
        try:
            descricao = request.form.get('descricao')
            valor = float(request.form.get('valor'))
            categoria = request.form.get('categoria')
            data_str = request.form.get('data')
            observacoes = request.form.get('observacoes')
            
            # Converter string de data para objeto date
            data = datetime.strptime(data_str, '%Y-%m-%d').date()
            
            # Criar nova despesa
            nova_despesa = Despesa(
                descricao=descricao,
                valor=valor,
                categoria=categoria,
                data=data,
                observacoes=observacoes
            )
            
            db.session.add(nova_despesa)
            db.session.commit()
            
            flash('Despesa adicionada com sucesso!', 'success')
            return redirect(url_for('index'))
            
        except Exception as e:
            flash(f'Erro ao adicionar despesa: {str(e)}', 'error')
            return redirect(url_for('adicionar'))
    
    return render_template('adicionar.html', categorias=Config.CATEGORIAS)


@app.route('/editar/<int:id>', methods=['GET', 'POST'])
def editar(id):
    """Editar despesa existente"""
    despesa = Despesa.query.get_or_404(id)
    
    if request.method == 'POST':
        try:
            despesa.descricao = request.form.get('descricao')
            despesa.valor = float(request.form.get('valor'))
            despesa.categoria = request.form.get('categoria')
            data_str = request.form.get('data')
            despesa.data = datetime.strptime(data_str, '%Y-%m-%d').date()
            despesa.observacoes = request.form.get('observacoes')
            
            db.session.commit()
            
            flash('Despesa atualizada com sucesso!', 'success')
            return redirect(url_for('index'))
            
        except Exception as e:
            flash(f'Erro ao atualizar despesa: {str(e)}', 'error')
            return redirect(url_for('editar', id=id))
    
    return render_template('editar.html', despesa=despesa, categorias=Config.CATEGORIAS)


@app.route('/excluir/<int:id>', methods=['POST'])
def excluir(id):
    """Excluir despesa"""
    try:
        despesa = Despesa.query.get_or_404(id)
        db.session.delete(despesa)
        db.session.commit()
        
        flash('Despesa excluída com sucesso!', 'success')
    except Exception as e:
        flash(f'Erro ao excluir despesa: {str(e)}', 'error')
    
    return redirect(url_for('index'))


@app.route('/exportar-sheets', methods=['POST'])
def exportar_sheets():
    """Exportar despesas para Google Sheets"""
    try:
        # Verificar se o arquivo de credenciais existe
        credentials_path = 'credentials.json'
        if not os.path.exists(credentials_path):
            flash('Arquivo de credenciais do Google não encontrado. Configure credentials.json primeiro.', 'error')
            return redirect(url_for('index'))
        
        # Configurar credenciais do Google Sheets
        scope = ['https://spreadsheets.google.com/feeds',
                'https://www.googleapis.com/auth/drive']
        
        creds = ServiceAccountCredentials.from_json_keyfile_name(credentials_path, scope)
        client = gspread.authorize(creds)
        
        # Nome da planilha (você pode personalizar)
        sheet_name = request.form.get('sheet_name', 'Controle de Despesas')
        
        # Tentar abrir planilha existente ou criar nova
        try:
            spreadsheet = client.open(sheet_name)
            worksheet = spreadsheet.sheet1
            # Limpar dados existentes
            worksheet.clear()
        except gspread.SpreadsheetNotFound:
            spreadsheet = client.create(sheet_name)
            worksheet = spreadsheet.sheet1
        
        # Buscar todas as despesas
        despesas = Despesa.query.order_by(Despesa.data.desc()).all()
        
        # Preparar dados para exportação
        headers = ['ID', 'Data', 'Descrição', 'Categoria', 'Valor', 'Observações']
        data = [headers]
        
        for despesa in despesas:
            row = [
                despesa.id,
                despesa.data.strftime('%d/%m/%Y'),
                despesa.descricao,
                despesa.categoria,
                despesa.valor,
                despesa.observacoes or ''
            ]
            data.append(row)
        
        # Adicionar linha de total
        total = sum(d.valor for d in despesas)
        data.append(['', '', '', 'TOTAL', total, ''])
        
        # Atualizar planilha
        worksheet.update('A1', data)
        
        # Formatar cabeçalho
        worksheet.format('A1:F1', {
            'textFormat': {'bold': True},
            'backgroundColor': {'red': 0.2, 'green': 0.6, 'blue': 0.9}
        })
        
        flash(f'Despesas exportadas com sucesso para "{sheet_name}"!', 'success')
        
    except Exception as e:
        flash(f'Erro ao exportar para Google Sheets: {str(e)}', 'error')
    
    return redirect(url_for('index'))


@app.route('/api/despesas')
def api_despesas():
    """API para obter despesas em formato JSON"""
    despesas = Despesa.query.order_by(Despesa.data.desc()).all()
    return jsonify([despesa.to_dict() for despesa in despesas])


if __name__ == '__main__':
    import os
    port = int(os.environ.get('PORT', 5000))
    app.run(debug=False, host='0.0.0.0', port=port)
